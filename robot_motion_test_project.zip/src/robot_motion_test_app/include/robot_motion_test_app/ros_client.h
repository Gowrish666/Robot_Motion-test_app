#ifndef ROBOT_MOTION_TEST_APP_ROS_CLIENT_H
#define ROBOT_MOTION_TEST_APP_ROS_CLIENT_H

#include <QObject>
#include <QString>
#include <QStringList>
#include <memory>

#include <ros/ros.h>
#include <graph_msgs/Graph.h>
#include <robot_motion_test_msgs/MoveToWaypoint.h>
#include <std_msgs/Float64MultiArray.h>
#include <std_msgs/Bool.h>
#include <std_msgs/String.h>
#include <actionlib_msgs/GoalID.h>
#include <dynamic_reconfigure/Reconfigure.h>

class RosClient : public QObject
{
    Q_OBJECT

public:
    explicit RosClient(QObject* parent = nullptr);
    ~RosClient();

    QStringList waypointIds() const;

    bool sendGoal(
        const QString& startWaypoint,
        const QString& goalWaypoint);

    bool configureMotion(
        double maxVelocity,
        double acceleration);

    void triggerSto();
    void triggerSafeStop();
    void stopRobot();

signals:
    void velocityUpdated(
        double velocity,
        double distance,
        double time);

    void waypointsUpdated();

    void goalReached();

private:
    void graphCallback(
        const graph_msgs::Graph::ConstPtr& msg);

    void telemetryCallback(
        const std_msgs::Float64MultiArray::ConstPtr& msg);

    void goalReachedCallback(
        const std_msgs::Bool::ConstPtr& msg);

    ros::NodeHandle node_handle_;

    ros::Subscriber graph_subscriber_;
    ros::Subscriber telemetry_subscriber_;
    ros::Subscriber goal_reached_subscriber_;

    ros::ServiceClient move_to_waypoint_client_;
    ros::ServiceClient motion_config_client_;

    ros::Publisher sto_publisher_;
    ros::Publisher safe_stop_publisher_;
    ros::Publisher mission_cancel_publisher_;

    std::unique_ptr<ros::AsyncSpinner> spinner_;

    QStringList waypoint_ids_;
};

#endif