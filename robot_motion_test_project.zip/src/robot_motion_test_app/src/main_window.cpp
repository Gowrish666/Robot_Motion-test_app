#include "robot_motion_test_app/main_window.h"

#include "robot_motion_test_app/dialogs.h"
#include "robot_motion_test_app/graph_widget.h"
#include "robot_motion_test_app/ros_client.h"
#include "robot_motion_test_app/test_execution_controller.h"

#include "ui_main_window.h"

#include <QComboBox>
#include <QFrame>
#include <QHBoxLayout>
#include <QLabel>
#include <QListWidget>
#include <QMessageBox>
#include <QPushButton>
#include <QVBoxLayout>

#include <utility>

// Creates the main application window.
MainWindow::MainWindow(QWidget* parent)
    : QMainWindow(parent),
      ui_(new Ui::MainWindow),
      data_access_(
          new robot_motion_test_data::DataAccessLayer),
      ros_client_(new RosClient(this)),
      execution_controller_(
          new TestExecutionController(
              ros_client_.get(),
              this)),
      velocity_time_graph_(nullptr),
      velocity_distance_graph_(nullptr),
      acceleration_time_graph_(nullptr),
      live_start_time_(0.0),
      live_start_distance_(0.0),
      live_previous_time_(0.0),
      live_previous_velocity_(0.0),
      live_telemetry_initialized_(false),
      warning_widget_(nullptr),
      mixed_order_overridden_(false),
      testing_active_(false)
{
    ui_->setupUi(this);

    connect(
        ros_client_.get(),
        &RosClient::waypointsUpdated,
        this,
        &MainWindow::updateWaypointList);

    updateWaypointList();

    ui_->leftSidebar->setMinimumWidth(0);
    ui_->leftSidebar->setMaximumWidth(
        QWIDGETSIZE_MAX);

    ui_->rightSidebar->setMinimumWidth(0);
    ui_->rightSidebar->setMaximumWidth(
        QWIDGETSIZE_MAX);

    ui_->centerArea->setMinimumWidth(0);
    ui_->centerArea->setMaximumWidth(
        QWIDGETSIZE_MAX);

    ui_->bodyLayout->setStretch(
        0,
        2);

    ui_->bodyLayout->setStretch(
        1,
        6);

    ui_->bodyLayout->setStretch(
        2,
        2);

    velocity_time_graph_ =
        new GraphWidget(
            "Velocity vs Time",
            "Time (s)",
            "Velocity (m/s)",
            ui_->centerArea);

    velocity_distance_graph_ =
        new GraphWidget(
            "Velocity vs Distance",
            "Distance (m)",
            "Velocity (m/s)",
            ui_->centerArea);

    acceleration_time_graph_ =
        new GraphWidget(
            "Acceleration vs Time",
            "Time (s)",
            "Acceleration (m/s²)",
            ui_->centerArea);

    ui_->centerLayout->addWidget(
        velocity_time_graph_,
        1);

    ui_->centerLayout->addWidget(
        velocity_distance_graph_,
        1);

    ui_->centerLayout->addWidget(
        acceleration_time_graph_,
        1);

    /*
     * Direct telemetry -> graph connection.
     *
     * We intentionally do not use the controller's graph
     * signals here. The graphs consume the same telemetry
     * that is already proven to reach the Qt application.
     */
    connect(
        ros_client_.get(),
        &RosClient::velocityUpdated,
        this,
        &MainWindow::updateLiveTelemetry);

    ui_->startWaypointComboBox
        ->setEditable(true);

    ui_->goalWaypointComboBox
        ->setEditable(true);

    ui_->startWaypointComboBox
        ->setInsertPolicy(
            QComboBox::NoInsert);

    ui_->goalWaypointComboBox
        ->setInsertPolicy(
            QComboBox::NoInsert);

    connect(
        ui_->addTestCaseButton,
        &QPushButton::clicked,
        this,
        &MainWindow::addTestCase);

    connect(
        ui_->startButton,
        &QPushButton::clicked,
        this,
        &MainWindow::startTesting);

    connect(
        ui_->stopButton,
        &QPushButton::clicked,
        this,
        &MainWindow::stopTesting);

    connect(
        execution_controller_.get(),
        &TestExecutionController::testStarted,
        this,
        &MainWindow::testStarted);

    connect(
        execution_controller_.get(),
        &TestExecutionController::executionStopped,
        this,
        &MainWindow::executionStopped);

    connect(
    execution_controller_.get(),
    &TestExecutionController::executionCompleted,
    this,
    &MainWindow::executionCompleted);

    connect(
        execution_controller_.get(),
        &TestExecutionController::statusChanged,
        this,
        [this](const QString& status)
        {
            ui_->statusLabel->setText(
                "Status: " + status);
        });

    connect(
    execution_controller_.get(),
    &TestExecutionController::loadRequired,
    this,
    [this](double massKg)
    {
        LoadPromptDialog dialog(
            massKg,
            this);

        const int result = dialog.exec();

        if (result == QDialog::Accepted)
        {
            execution_controller_->loadAccepted();
        }
        else
        {
            execution_controller_->stop();
        }
    });

    ui_->stopButton->setEnabled(false);

    ui_->statusLabel->setText(
        "Status: IDLE");

    ui_->currentTestLabel->setText(
        "Current Test: --");

    ui_->iterationLabel->setText(
        "Iteration: --");

    ui_->velocityLabel->setText(
        "Velocity: --");

    ui_->distanceLabel->setText(
        "Distance: --");

    if (!data_access_->initialize())
    {
        QMessageBox::warning(
            this,
            "MongoDB",
            "Could not connect to MongoDB.");
    }

    updateWaypointList();

    loadTestCases();

    updateQueueController();
}

// Destroys the main application window.
MainWindow::~MainWindow()
{
    delete ui_;
}

// Opens the add test case dialog.
void MainWindow::addTestCase()
{
    if (testing_active_)
        return;

    AddTestCaseDialog dialog(this);

    if (dialog.exec() !=
        QDialog::Accepted)
    {
        return;
    }

    const robot_motion_test_data::TestCase
        test_case =
            dialog.testCase();

    if (!data_access_->createTestCase(
            test_case))
    {
        QMessageBox::warning(
            this,
            "Test Case",
            "Could not create the test case.\n"
            "The name may already exist.");

        return;
    }

    mixed_order_overridden_ = false;

    loadTestCases();
}

// Opens the selected test case for editing.
void MainWindow::editTestCase()
{
    if (testing_active_)
        return;

    const int index =
        selectedTestIndex();

    if (index < 0 ||
        index >=
            static_cast<int>(
                test_cases_.size()))
    {
        return;
    }

    AddTestCaseDialog dialog(
        test_cases_[index],
        this);

    if (dialog.exec() !=
        QDialog::Accepted)
    {
        return;
    }

    const robot_motion_test_data::TestCase
        updated =
            dialog.testCase();

    if (!data_access_->updateTestCase(
            test_cases_[index].name,
            updated))
    {
        QMessageBox::warning(
            this,
            "Test Case",
            "Could not update the test case.");

        return;
    }

    mixed_order_overridden_ = false;

    loadTestCases();
}

// Removes the selected test case.
void MainWindow::removeTestCase()
{
    if (testing_active_)
        return;

    const int index =
        selectedTestIndex();

    if (index < 0 ||
        index >=
            static_cast<int>(
                test_cases_.size()))
    {
        return;
    }

    const QString name =
        QString::fromStdString(
            test_cases_[index].name);

    const QMessageBox::StandardButton
        answer =
            QMessageBox::question(
                this,
                "Delete Test Case",
                "Delete \"" +
                    name +
                    "\"?",
                QMessageBox::Yes |
                QMessageBox::No,
                QMessageBox::No);

    if (answer != QMessageBox::Yes)
        return;

    if (!data_access_->deleteTestCase(
            test_cases_[index].name))
    {
        QMessageBox::warning(
            this,
            "Test Case",
            "Could not delete the test case.");

        return;
    }

    mixed_order_overridden_ = false;

    loadTestCases();
}

// Moves the selected test case upward.
void MainWindow::moveTestCaseUp()
{
    if (testing_active_)
        return;

    const int index =
        selectedTestIndex();

    if (index <= 0)
        return;

    std::swap(
        test_cases_[index],
        test_cases_[index - 1]);

    mixed_order_overridden_ = false;

    updateTestCaseList();

    ui_->testCaseList->setCurrentRow(
        index - 1);

    updateQueueController();
}

// Moves the selected test case downward.
void MainWindow::moveTestCaseDown()
{
    if (testing_active_)
        return;

    const int index =
        selectedTestIndex();

    if (index < 0 ||
        index >=
            static_cast<int>(
                test_cases_.size()) - 1)
    {
        return;
    }

    std::swap(
        test_cases_[index],
        test_cases_[index + 1]);

    mixed_order_overridden_ = false;

    updateTestCaseList();

    ui_->testCaseList->setCurrentRow(
        index + 1);

    updateQueueController();
}

// Starts test execution.
void MainWindow::startTesting()
{
    if (execution_controller_->isRunning())
        return;

    if (test_cases_.empty())
    {
        QMessageBox::warning(
            this,
            "Start Testing",
            "No test cases have been added.");

        return;
    }

    const QString start_waypoint =
        ui_->startWaypointComboBox
            ->currentText()
            .trimmed();

    const QString goal_waypoint =
        ui_->goalWaypointComboBox
            ->currentText()
            .trimmed();

    if (start_waypoint.isEmpty() ||
        goal_waypoint.isEmpty())
    {
        QMessageBox::warning(
            this,
            "Start Testing",
            "Select both start and goal waypoints.");

        return;
    }

    if (start_waypoint ==
        goal_waypoint)
    {
        QMessageBox::warning(
            this,
            "Start Testing",
            "Start and goal waypoints "
            "must be different.");

        return;
    }

    const QMessageBox::StandardButton
        answer =
            QMessageBox::question(
                this,
                "Start Testing",
                "Do you want to continue?",
                QMessageBox::Ok |
                QMessageBox::Cancel,
                QMessageBox::Cancel);

    if (answer != QMessageBox::Ok)
    {
        return;
    }

    /*
     * Clear previous graph data before starting
     * the new test session.
     */
    clearLiveGraphs();

    execution_controller_->setTestCases(
        test_cases_);

    execution_controller_->setWaypoints(
        start_waypoint,
        goal_waypoint);

    testing_active_ = true;

    setTestCaseEditingEnabled(false);

    ui_->startButton->setEnabled(false);

    ui_->stopButton->setEnabled(true);

    updateTestCaseList();

    execution_controller_->start();
}

// Stops test execution.
void MainWindow::stopTesting()
{
    if (!execution_controller_->isRunning())
        return;

    execution_controller_->stop();
}

// Updates the current test information.
void MainWindow::testStarted(
    const QString& name,
    int iteration)
{
    ui_->currentTestLabel->setText(
        "Current Test: " + name);

    ui_->iterationLabel->setText(
        QString("Iteration: %1")
            .arg(iteration));

    ui_->statusLabel->setText(
        "Status: RUNNING");

       current_running_test_index_ = -1;

    for (int i = 0;
         i < static_cast<int>(test_cases_.size());
         ++i)
    {
        if (QString::fromStdString(
                test_cases_[i].name) == name)
        {
            current_running_test_index_ = i;
            break;
        }
    }

}

// Handles execution stopping.
void MainWindow::executionStopped()
{
    testing_active_ = false;

    setTestCaseEditingEnabled(true);

    ui_->startButton->setEnabled(true);

    ui_->stopButton->setEnabled(false);

    ui_->statusLabel->setText(
        "Status: STOPPED");

    updateTestCaseList();
}

void MainWindow::executionCompleted()
{
    // Force the final displayed velocity to zero.
    if (!live_velocity_time_data_.isEmpty())
    {
        QPointF last = live_velocity_time_data_.last();
        last.setY(0.0);
        live_velocity_time_data_[live_velocity_time_data_.size() - 1] = last;
    }

    if (!live_velocity_distance_data_.isEmpty())
    {
        QPointF last = live_velocity_distance_data_.last();
        last.setY(0.0);
        live_velocity_distance_data_[live_velocity_distance_data_.size() - 1] = last;
    }

    velocity_time_graph_->setData(
        live_velocity_time_data_);

    velocity_distance_graph_->setData(
        live_velocity_distance_data_);

    testing_active_ = false;
    current_running_test_index_ = -1;

    setTestCaseEditingEnabled(true);

    ui_->startButton->setEnabled(true);

    ui_->stopButton->setEnabled(false);

    ui_->statusLabel->setText(
        "Status: COMPLETED");

    updateTestCaseList();
}

// Clears all live graph data.
void MainWindow::clearLiveGraphs()
{
    live_velocity_time_data_.clear();

    live_velocity_distance_data_.clear();

    live_acceleration_time_data_.clear();

    live_start_time_ = 0.0;

    live_start_distance_ = 0.0;

    live_previous_time_ = 0.0;

    live_previous_velocity_ = 0.0;

    live_telemetry_initialized_ = false;

    velocity_time_graph_->setData(
        live_velocity_time_data_);

    velocity_distance_graph_->setData(
        live_velocity_distance_data_);

    acceleration_time_graph_->setData(
        live_acceleration_time_data_);
}

// Updates the graphs and live labels from telemetry.
void MainWindow::updateLiveTelemetry(
    double velocity,
    double distance,
    double time)
{
    /*
     * Only display telemetry as part of an active test.
     */
    if (!testing_active_)
    {
        return;
    }

    /*
     * First telemetry sample establishes the origin
     * for the current test's graphs.
     */
    if (!live_telemetry_initialized_)
    {
        live_start_time_ = time;

        live_start_distance_ = distance;

        live_previous_time_ = time;

        live_previous_velocity_ = velocity;

        live_telemetry_initialized_ = true;
    }

    const double plot_time =
        time - live_start_time_;

    const double plot_distance =
        distance - live_start_distance_;

    live_velocity_time_data_.append(
        QPointF(
            plot_time,
            velocity));

    live_velocity_distance_data_.append(
        QPointF(
            plot_distance,
            velocity));

    /*
     * Calculate acceleration from consecutive
     * telemetry samples.
     */
    if (time > live_previous_time_)
    {
        const double dt =
            time - live_previous_time_;

        if (dt > 0.0)
        {
            const double acceleration =
                (velocity -
                 live_previous_velocity_) /
                dt;

            live_acceleration_time_data_.append(
                QPointF(
                    plot_time,
                    acceleration));
        }
    }

    live_previous_time_ = time;

    live_previous_velocity_ = velocity;

    velocity_time_graph_->setData(
        live_velocity_time_data_);

    velocity_distance_graph_->setData(
        live_velocity_distance_data_);

    acceleration_time_graph_->setData(
        live_acceleration_time_data_);

    ui_->velocityLabel->setText(
        QString("Velocity: %1 m/s")
            .arg(
                velocity,
                0,
                'f',
                3));

    ui_->distanceLabel->setText(
        QString("Distance: %1 m")
            .arg(
                plot_distance,
                0,
                'f',
                3));
}

// Loads test cases from MongoDB.
void MainWindow::loadTestCases()
{
    if (!data_access_->isConnected())
    {
        test_cases_.clear();

        updateTestCaseList();

        return;
    }

    test_cases_ =
        data_access_->getAllTestCases();

    updateTestCaseList();
}

// Updates the test case list.
void MainWindow::updateTestCaseList()
{
    ui_->testCaseList->clear();

    for (int i = 0;
         i <
         static_cast<int>(
             test_cases_.size());
         ++i)
    {
        QListWidgetItem* item =
            new QListWidgetItem(
                ui_->testCaseList);

        QWidget* row =
            new QWidget;

        if (i == current_running_test_index_)
{
    row->setStyleSheet(
        "QWidget {"
        "background-color: #dbeafe;"
        "}");
}

        QVBoxLayout* row_layout =
            new QVBoxLayout(row);

        row_layout->setContentsMargins(
            0,
            0,
            0,
            0);

        row_layout->setSpacing(0);

        QWidget* content_widget =
            new QWidget(row);

        QHBoxLayout* content_layout =
            new QHBoxLayout(
                content_widget);

        
if (i == current_running_test_index_)
{
    content_widget->setStyleSheet(
        "QWidget {"
        "background-color: #dbeafe;"
        "}");
}

        content_layout->setContentsMargins(
            12,
            7,
            8,
            7);

        content_layout->setSpacing(6);

        const auto& test_case =
            test_cases_[i];

        QString load_text;

        if (test_case.load_condition ==
            robot_motion_test_data::
                LoadCondition::UNDER_LOAD)
        {
            load_text = "Loaded";
        }
        else
        {
            load_text = "Unloaded";
        }

        QString braking_text;

        switch (test_case.braking_type)
        {
        case robot_motion_test_data::
            BrakingType::STO:
            braking_text = "STO";
            break;

        case robot_motion_test_data::
            BrakingType::SAFE_STOP:
            braking_text = "Safe-Stop";
            break;

        case robot_motion_test_data::
            BrakingType::NONE:
            braking_text = "No Braking";
            break;
        }

        QWidget* text_widget =
            new QWidget(row);

        QVBoxLayout* text_layout =
            new QVBoxLayout(text_widget);

        text_layout->setContentsMargins(
            0,
            0,
            0,
            0);

        text_layout->setSpacing(1);

        QLabel* name =
            new QLabel(
                QString::fromStdString(
                    test_case.name));

        name->setWordWrap(true);

        name->setStyleSheet(
            "QLabel {"
            "font-size: 14px;"
            "font-weight: 600;"
            "}");

        QLabel* details =
            new QLabel(
                load_text +
                "    " +
                QString("v = %1")
                    .arg(
                        QString::number(
                            test_case.max_velocity_mps,
                            'g',
                            6)) +
                "    " +
                braking_text);

        details->setWordWrap(true);

        details->setStyleSheet(
            "QLabel {"
            "font-size: 10px;"
            "color: #666666;"
            "}");

        text_layout->addWidget(
            name);

        text_layout->addWidget(
            details);

        // Uses a trash-bin icon for deletion.
        QPushButton* delete_button =
            new QPushButton(
                QString::fromUtf8(
                    "\xF0\x9F\x97\x91"));

        delete_button->setEnabled(
            !testing_active_);

        delete_button->setFixedSize(
            24,
            24);

        delete_button->setToolTip(
            "Delete Test Case");

        delete_button->setStyleSheet(
            "QPushButton {"
            "border: 1px solid palette(mid);"
            "border-radius: 12px;"
            "font-size: 13px;"
            "}"
            "QPushButton:hover {"
            "background: #f0d0d0;"
            "}");

        QPushButton* edit_button =
            new QPushButton("✎");

        edit_button->setEnabled(
            !testing_active_);

        edit_button->setFixedSize(
            24,
            24);

        edit_button->setToolTip(
            "Edit Test Case");

        edit_button->setStyleSheet(
            "QPushButton {"
            "border: 1px solid palette(mid);"
            "border-radius: 12px;"
            "font-size: 16px;"
            "}"
            "QPushButton:hover {"
            "background: palette(alternate-base);"
            "}");

        content_layout->addWidget(
            text_widget,
            1,
            Qt::AlignLeft |
            Qt::AlignVCenter);

        content_layout->addWidget(
            delete_button,
            0,
            Qt::AlignRight |
            Qt::AlignVCenter);

        content_layout->addWidget(
            edit_button,
            0,
            Qt::AlignRight |
            Qt::AlignVCenter);

        QFrame* separator =
            new QFrame(row);

        separator->setFrameShape(
            QFrame::HLine);

        separator->setFrameShadow(
            QFrame::Plain);

        separator->setFixedHeight(1);

        separator->setStyleSheet(
            "QFrame {"
            "color: #d0d0d0;"
            "background-color: #d0d0d0;"
            "}");

        row_layout->addWidget(
            content_widget);

        row_layout->addWidget(
            separator);

        item->setData(
            Qt::UserRole,
            i);

        item->setSizeHint(
            QSize(0, 68));

        ui_->testCaseList->setItemWidget(
            item,
            row);

        connect(
            delete_button,
            &QPushButton::clicked,
            this,
            [this, i]()
            {
                if (i < 0 ||
                    i >=
                        static_cast<int>(
                            test_cases_.size()))
                {
                    return;
                }

                ui_->testCaseList
                    ->setCurrentRow(i);

                removeTestCase();
            });

        connect(
            edit_button,
            &QPushButton::clicked,
            this,
            [this, i]()
            {
                if (i < 0 ||
                    i >=
                        static_cast<int>(
                            test_cases_.size()))
                {
                    return;
                }

                ui_->testCaseList
                    ->setCurrentRow(i);

                editTestCase();
            });
    }

    ui_->testCaseCountLabel->setText(
        QString("No: %1")
            .arg(test_cases_.size()));

    showMixedLoadWarningIfNeeded();
}

// Updates the waypoint lists.
void MainWindow::updateWaypointList()
{
    ui_->startWaypointComboBox->clear();

    ui_->goalWaypointComboBox->clear();

    const QStringList waypoint_ids =
        ros_client_->waypointIds();

    ui_->startWaypointComboBox
        ->addItems(waypoint_ids);

    ui_->goalWaypointComboBox
        ->addItems(waypoint_ids);

    ui_->startWaypointComboBox
        ->setCurrentIndex(-1);

    ui_->goalWaypointComboBox
        ->setCurrentIndex(-1);
}

// Updates the execution queue.
void MainWindow::updateQueueController()
{
    execution_controller_->setTestCases(
        test_cases_);
}

// Displays the mixed-load warning when required.
void MainWindow::showMixedLoadWarningIfNeeded()
{
    clearRightDynamicPanel();

    if (!hasMixedLoadOrder() ||
        mixed_order_overridden_)
    {
        return;
    }

    warning_widget_ =
        new QWidget(
            ui_->rightDynamicContainer);

    QVBoxLayout* layout =
        new QVBoxLayout(
            warning_widget_);

    layout->setContentsMargins(
        8,
        12,
        8,
        12);

    layout->setSpacing(8);

    QLabel* icon =
        new QLabel("⚠");

    icon->setAlignment(
        Qt::AlignCenter);

    icon->setStyleSheet(
        "font-size: 28px;"
        "color: #d9a300;");

    QLabel* text =
        new QLabel(
            "Unloaded conditions have "
            "to be done first.");

    text->setAlignment(
        Qt::AlignCenter);

    text->setWordWrap(true);

    QPushButton* override_button =
        new QPushButton(
            "OVERRIDE");

    override_button->setFixedHeight(
        32);

    layout->addWidget(icon);

    layout->addWidget(text);

    layout->addWidget(
        override_button);

    ui_->rightDynamicLayout
        ->addWidget(
            warning_widget_);

    connect(
        override_button,
        &QPushButton::clicked,
        this,
        [this]()
        {
            mixed_order_overridden_ = true;

            clearRightDynamicPanel();
        });
}

// Determines whether an unloaded case appears after a loaded case.
bool MainWindow::hasMixedLoadOrder() const
{
    bool seen_under_load = false;

    for (const auto& test_case :
         test_cases_)
    {
        if (test_case.load_condition ==
            robot_motion_test_data::
                LoadCondition::UNDER_LOAD)
        {
            seen_under_load = true;
        }
        else if (seen_under_load)
        {
            return true;
        }
    }

    return false;
}

// Removes conditional content from the right sidebar.
void MainWindow::clearRightDynamicPanel()
{
    while (QLayoutItem* item =
               ui_->rightDynamicLayout
                   ->takeAt(0))
    {
        if (QWidget* widget =
                item->widget())
        {
            widget->deleteLater();
        }

        delete item;
    }

    warning_widget_ = nullptr;
}

// Enables or disables test-case editing controls.
void MainWindow::setTestCaseEditingEnabled(
    bool enabled)
{
    ui_->addTestCaseButton->setEnabled(
        enabled);
}

// Returns the selected test case index.
int MainWindow::selectedTestIndex() const
{
    QListWidgetItem* item =
        ui_->testCaseList->currentItem();

    if (!item)
        return -1;

    const int index =
        item->data(
            Qt::UserRole).toInt();

    if (index < 0 ||
        index >=
            static_cast<int>(
                test_cases_.size()))
    {
        return -1;
    }

    return index;
}