#include "robot_motion_test_app/ros_client.h"

#include <actionlib_msgs/GoalID.h>
#include <std_msgs/String.h>
#include <dynamic_reconfigure/Config.h>

RosClient::RosClient(QObject* parent)
    : QObject(parent)
{
    /*
     * ------------------------------------------------------------
     * GRAPH / WAYPOINT SUBSCRIBER
     * ------------------------------------------------------------
     */
    graph_subscriber_ =
        node_handle_.subscribe(
            "/graph",
            1,
            &RosClient::graphCallback,
            this);

    /*
     * ------------------------------------------------------------
     * TELEMETRY SUBSCRIBER
     * ------------------------------------------------------------
     *
     * Expected telemetry:
     *
     * data[0] = time
     * data[1] = velocity
     * data[2] = distance
     * data[3] = additional telemetry value
     */
    telemetry_subscriber_ =
        node_handle_.subscribe(
            "/robot_motion_test/telemetry",
            20,
            &RosClient::telemetryCallback,
            this);

    /*
     * ------------------------------------------------------------
     * MOVE TO WAYPOINT SERVICE
     * ------------------------------------------------------------
     */
    move_to_waypoint_client_ =
        node_handle_.serviceClient<
            robot_motion_test_msgs::MoveToWaypoint>(
                "/move_to_waypoint");

    /*
     * ------------------------------------------------------------
     * DYNAMIC RECONFIGURE SERVICE
     * ------------------------------------------------------------
     *
     * This is used by the test controller to configure:
     *
     *     max_vel
     *     max_acc
     *     max_decel
     *
     * before every test case / iteration.
     */
    motion_config_client_ =
        node_handle_.serviceClient<
            dynamic_reconfigure::Reconfigure>(
                "/move_base/AnscerLocalPlanner/set_parameters");

    /*
     * ------------------------------------------------------------
     * BRAKING PLACEHOLDERS
     * ------------------------------------------------------------
     *
     * Real STO / Safe-Stop interfaces are not currently
     * advertised by the simulation.
     */
    sto_publisher_ =
        node_handle_.advertise<std_msgs::String>(
            "/dummy_robot/sto",
            1);

    safe_stop_publisher_ =
        node_handle_.advertise<std_msgs::String>(
            "/dummy_robot/safe_stop",
            1);

    /*
     * ------------------------------------------------------------
     * MISSION CANCEL
     * ------------------------------------------------------------
     */
    mission_cancel_publisher_ =
        node_handle_.advertise<actionlib_msgs::GoalID>(
            "/execute_mission/cancel",
            1);

    /*
     * ------------------------------------------------------------
     * GOAL REACHED SUBSCRIBER
     * ------------------------------------------------------------
     */
    goal_reached_subscriber_ =
        node_handle_.subscribe(
            "/robot_motion_test/goal_reached",
            10,
            &RosClient::goalReachedCallback,
            this);

    /*
     * ------------------------------------------------------------
     * ROS ASYNC SPINNER
     * ------------------------------------------------------------
     */
    spinner_ =
        std::make_unique<ros::AsyncSpinner>(1);

    spinner_->start();
}

RosClient::~RosClient()
{
    if (spinner_)
    {
        spinner_->stop();
    }
}


/*
 * ================================================================
 * WAYPOINT IDS
 * ================================================================
 */

QStringList RosClient::waypointIds() const
{
    return waypoint_ids_;
}


/*
 * ================================================================
 * GRAPH CALLBACK
 * ================================================================
 */

void RosClient::graphCallback(
    const graph_msgs::Graph::ConstPtr& msg)
{
    QStringList new_waypoints;

    for (const auto& vertex : msg->vertices)
    {
        QString waypoint;

        /*
         * Prefer waypoint name.
         */
        if (!vertex.name.empty())
        {
            waypoint =
                QString::fromStdString(
                    vertex.name);
        }

        /*
         * Otherwise use alias.
         */
        else if (!vertex.alias.empty())
        {
            waypoint =
                QString::fromStdString(
                    vertex.alias);
        }

        /*
         * Otherwise fall back to numeric ID.
         */
        else
        {
            waypoint =
                QString::number(vertex.id);
        }

        /*
         * Avoid empty or duplicate waypoint names.
         */
        if (!waypoint.isEmpty() &&
            !new_waypoints.contains(waypoint))
        {
            new_waypoints.append(waypoint);
        }
    }

    /*
     * Only notify MainWindow when the waypoint list
     * actually changes.
     */
    if (new_waypoints != waypoint_ids_)
    {
        waypoint_ids_ = new_waypoints;

        emit waypointsUpdated();
    }
}


/*
 * ================================================================
 * TELEMETRY CALLBACK
 * ================================================================
 */

void RosClient::telemetryCallback(
    const std_msgs::Float64MultiArray::ConstPtr& msg)
{
    /*
     * We require at least:
     *
     *     data[0] = time
     *     data[1] = velocity
     *     data[2] = distance
     *     data[3] = additional telemetry
     */
    if (msg->data.size() < 4)
    {
        ROS_WARN_THROTTLE(
            5.0,
            "Telemetry message has fewer than 4 values.");

        return;
    }

    const double time =
        msg->data[0];

    const double velocity =
        msg->data[1];

    const double distance =
        msg->data[2];

    /*
     * Forward telemetry to the controller and MainWindow.
     */
    emit velocityUpdated(
        velocity,
        distance,
        time);
}


/*
 * ================================================================
 * GOAL REACHED CALLBACK
 * ================================================================
 */

void RosClient::goalReachedCallback(
    const std_msgs::Bool::ConstPtr& msg)
{
    if (msg->data)
    {
        emit goalReached();
    }
}


/*
 * ================================================================
 * CONFIGURE MOTION
 * ================================================================
 *
 * Configure the planner with:
 *
 *     maximum velocity
 *     acceleration
 *     deceleration
 *
 * The returned dynamic-reconfigure values are printed so we can
 * verify that the planner actually accepted the requested values.
 * ================================================================
 */

bool RosClient::configureMotion(
    double maxVelocity,
    double acceleration)
{
    /*
     * ------------------------------------------------------------
     * CHECK SERVICE
     * ------------------------------------------------------------
     */

    if (!motion_config_client_.waitForExistence(
            ros::Duration(1.0)))
    {
        ROS_ERROR(
            "Planner dynamic-reconfigure service is unavailable: "
            "/move_base/AnscerLocalPlanner/set_parameters");

        return false;
    }

    /*
     * ------------------------------------------------------------
     * CREATE RECONFIGURE REQUEST
     * ------------------------------------------------------------
     */

    dynamic_reconfigure::Reconfigure service;

    /*
     * Maximum velocity.
     */
    dynamic_reconfigure::DoubleParameter max_vel_param;

    max_vel_param.name =
        "max_vel";

    max_vel_param.value =
        maxVelocity;

    /*
     * Maximum acceleration.
     */
    dynamic_reconfigure::DoubleParameter max_acc_param;

    max_acc_param.name =
        "max_acc";

    max_acc_param.value =
        acceleration;

    /*
     * Maximum deceleration.
     *
     * We are keeping your existing behavior here:
     * deceleration = configured acceleration.
     */
    dynamic_reconfigure::DoubleParameter max_decel_param;

    max_decel_param.name =
        "max_decel";

    max_decel_param.value =
        acceleration;

    /*
     * Add parameters to the request.
     */
    service.request.config.doubles.push_back(
        max_vel_param);

    service.request.config.doubles.push_back(
        max_acc_param);

    service.request.config.doubles.push_back(
        max_decel_param);

    /*
     * ------------------------------------------------------------
     * CALL DYNAMIC RECONFIGURE
     * ------------------------------------------------------------
     */

    if (!motion_config_client_.call(service))
    {
        ROS_ERROR(
            "Failed to configure planner motion parameters.");

        return false;
    }

    /*
     * ------------------------------------------------------------
     * PRINT WHAT WAS REQUESTED
     * ------------------------------------------------------------
     */

    ROS_INFO(
        "==================================================");

    ROS_INFO(
        "Motion configuration requested:");

    ROS_INFO(
        "  max_vel   = %.4f m/s",
        maxVelocity);

    ROS_INFO(
        "  max_acc   = %.4f m/s^2",
        acceleration);

    ROS_INFO(
        "  max_decel = %.4f m/s^2",
        acceleration);

    /*
     * ------------------------------------------------------------
     * PRINT WHAT THE PLANNER RETURNED
     * ------------------------------------------------------------
     *
     * This is important.
     *
     * Previously the program only printed the values that we
     * requested. That did NOT prove that the planner accepted
     * them.
     *
     * Now we inspect the response.
     */
    if (service.response.config.doubles.empty())
    {
        ROS_WARN(
            "Dynamic-reconfigure returned no double parameters.");
    }
    else
    {
        ROS_INFO(
            "Planner returned motion parameters:");

        for (const auto& parameter :
             service.response.config.doubles)
        {
            ROS_INFO(
                "  %s = %.4f",
                parameter.name.c_str(),
                parameter.value);
        }
    }

    ROS_INFO(
        "==================================================");

    return true;
}


/*
 * ================================================================
 * SEND GOAL
 * ================================================================
 *
 * startWaypoint is intentionally not used here.
 *
 * The MoveToWaypoint service accepts the destination waypoint.
 * The robot's current physical position determines where it
 * starts from.
 *
 * Therefore:
 *
 *     sendGoal("", "V72")
 *
 * means:
 *
 *     Go to V72
 *
 * and:
 *
 *     sendGoal("", "V75")
 *
 * means:
 *
 *     Go to V75
 *
 * for the return trip.
 * ================================================================
 */

bool RosClient::sendGoal(
    const QString& startWaypoint,
    const QString& goalWaypoint)
{
    /*
     * The service currently only requires the destination.
     *
     * Keep the argument because the controller API uses:
     *
     *     startWaypoint -> goalWaypoint
     */
    Q_UNUSED(startWaypoint);

    /*
     * Destination is mandatory.
     */
    if (goalWaypoint.isEmpty())
    {
        ROS_ERROR(
            "Cannot send waypoint goal: goal waypoint is empty.");

        return false;
    }

    /*
     * ------------------------------------------------------------
     * CHECK MOVE-TO-WAYPOINT SERVICE
     * ------------------------------------------------------------
     */

    if (!move_to_waypoint_client_.waitForExistence(
            ros::Duration(1.0)))
    {
        ROS_ERROR(
            "MoveToWaypoint service is unavailable: "
            "/move_to_waypoint");

        return false;
    }

    /*
     * ------------------------------------------------------------
     * CREATE REQUEST
     * ------------------------------------------------------------
     */

    robot_motion_test_msgs::MoveToWaypoint service;

    service.request.waypoint_name =
        goalWaypoint.toStdString();

    ROS_INFO(
        "Sending waypoint goal: %s",
        goalWaypoint.toStdString().c_str());

    /*
     * ------------------------------------------------------------
     * CALL SERVICE
     * ------------------------------------------------------------
     */

    if (!move_to_waypoint_client_.call(service))
    {
        ROS_ERROR(
            "Failed to call /move_to_waypoint for waypoint: %s",
            goalWaypoint.toStdString().c_str());

        return false;
    }

    /*
     * ------------------------------------------------------------
     * CHECK RESPONSE
     * ------------------------------------------------------------
     */

    if (!service.response.success)
    {
        ROS_ERROR(
            "MoveToWaypoint rejected waypoint: %s",
            goalWaypoint.toStdString().c_str());

        return false;
    }

    ROS_INFO(
        "Waypoint goal accepted: %s",
        goalWaypoint.toStdString().c_str());

    return true;
}


/*
 * ================================================================
 * STO
 * ================================================================
 */

void RosClient::triggerSto()
{
    std_msgs::String message;

    message.data =
        "STO";

    sto_publisher_.publish(
        message);
}


/*
 * ================================================================
 * SAFE STOP
 * ================================================================
 */

void RosClient::triggerSafeStop()
{
    std_msgs::String message;

    message.data =
        "SAFE_STOP";

    safe_stop_publisher_.publish(
        message);
}


/*
 * ================================================================
 * STOP ROBOT
 * ================================================================
 *
 * Keep the existing cancellation mechanism unchanged.
 * ================================================================
 */

void RosClient::stopRobot()
{
    actionlib_msgs::GoalID cancel_message;

    mission_cancel_publisher_.publish(
        cancel_message);
}