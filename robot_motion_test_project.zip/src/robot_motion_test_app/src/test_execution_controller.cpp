#include "robot_motion_test_app/test_execution_controller.h"

#include <algorithm>
#include <cmath>
#include <QThread>


TestExecutionController::TestExecutionController(
    RosClient* rosClient,
    QObject* parent)
    : QObject(parent),
      ros_client_(rosClient),
      running_(false),
      current_test_index_(0),
      current_iteration_(0),
      waiting_for_load_(false),
      load_prompt_shown_(false),
      phase_(Phase::IDLE),
      braking_started_(false),
      return_motion_detected_(false),
      braking_start_distance_(0.0),
      braking_distance_(0.0),
      max_velocity_achieved_(0.0),
      previous_velocity_(0.0),
      previous_time_(0.0)
{
    connect(
        ros_client_,
        &RosClient::velocityUpdated,
        this,
        &TestExecutionController::telemetryUpdated);

    connect(
        ros_client_,
        &RosClient::goalReached,
        this,
        &TestExecutionController::goalReached);
}


// ============================================================
// SET TEST CASES
// ============================================================

void TestExecutionController::setTestCases(
    const std::vector<robot_motion_test_data::TestCase>& testCases)
{
    test_cases_ = testCases;
}


// ============================================================
// SET WAYPOINTS
// ============================================================

void TestExecutionController::setWaypoints(
    const QString& startWaypoint,
    const QString& goalWaypoint)
{
    start_waypoint_ = startWaypoint;
    goal_waypoint_ = goalWaypoint;
}


// ============================================================
// START COMPLETE TEST SEQUENCE
// ============================================================

void TestExecutionController::start()
{
    if (running_)
    {
        return;
    }

    if (test_cases_.empty())
    {
        return;
    }

    if (start_waypoint_.isEmpty() ||
        goal_waypoint_.isEmpty())
    {
        emit statusChanged(
            "Select start and goal waypoints.");

        return;
    }

    running_ = true;

    current_test_index_ = 0;

    current_iteration_ = 1;

    waiting_for_load_ = false;

    load_prompt_shown_ = false;

    phase_ = Phase::IDLE;

    braking_started_ = false;

    return_motion_detected_ = false;

    emit statusChanged(
        "Test sequence started.");

    /*
     * Start the first test case.
     *
     * If it requires load, startCurrentTest()
     * will show the load prompt and return.
     */
    startCurrentTest();
}


// ============================================================
// START CURRENT TEST CASE
// ============================================================

void TestExecutionController::startCurrentTest()
{
    if (!running_)
    {
        return;
    }

    if (current_test_index_ < 0 ||
        current_test_index_ >=
            static_cast<int>(test_cases_.size()))
    {
        running_ = false;

        waiting_for_load_ = false;

        phase_ = Phase::IDLE;

        emit statusChanged(
            "All tests completed.");

        emit executionCompleted();

        return;
    }

    const auto& testCase =
        test_cases_[current_test_index_];


    // ========================================================
    // LOAD HANDLING
    // ========================================================

    if (testCase.load_condition ==
        robot_motion_test_data::LoadCondition::UNDER_LOAD)
    {
        /*
         * If the load prompt has not yet been shown for
         * this test case, show it now.
         */
        if (!load_prompt_shown_)
        {
            waiting_for_load_ = true;

            load_prompt_shown_ = true;

            phase_ = Phase::IDLE;

            emit statusChanged(
                QString(
                    "Load required for %1. "
                    "Waiting for operator confirmation.")
                    .arg(
                        QString::fromStdString(
                            testCase.name)));

            emit loadRequired(
                testCase.load_mass_kg);

            /*
             * Do NOT continue.
             */
            return;
        }

        /*
         * The load prompt was already accepted for
         * this test case.
         */
        if (waiting_for_load_)
        {
            return;
        }
    }


    // ========================================================
    // NO LOAD / LOAD ALREADY ACCEPTED
    // ========================================================

    waiting_for_load_ = false;

    /*
     * Clear data only when the actual iteration starts.
     */
    clearCurrentData();


    // ========================================================
    // MOVING TO GOAL
    // ========================================================

    phase_ = Phase::MOVING_TO_GOAL;

    braking_started_ = false;

    return_motion_detected_ = false;


    emit testStarted(
        QString::fromStdString(
            testCase.name),
        current_iteration_);


    emit statusChanged(
        QString(
            "Running %1 iteration %2")
            .arg(
                QString::fromStdString(
                    testCase.name))
            .arg(
                current_iteration_));


    // ========================================================
    // CONFIGURE ROBOT
    // ========================================================

    /*
     * Apply the requested test-case velocity and
     * acceleration before starting navigation.
     */
    if (!ros_client_->configureMotion(
            testCase.max_velocity_mps,
            testCase.acceleration_mps2))
    {
        running_ = false;

        waiting_for_load_ = false;

        phase_ = Phase::IDLE;

        emit statusChanged(
            "Failed to configure robot motion.");

        emit executionStopped();

        return;
    }


    /*
     * Give dynamic_reconfigure time to propagate through
     * the planner before the navigation goal is sent.
     *
     * This is especially important when moving from one
     * test case to another with a different max velocity.
     */
    QThread::msleep(300);


    // ========================================================
    // SEND TEST GOAL
    // ========================================================

    /*
     * Normal test movement:
     *
     * V75 -> V72/V74
     */
    if (!ros_client_->sendGoal(
            start_waypoint_,
            goal_waypoint_))
    {
        running_ = false;

        waiting_for_load_ = false;

        phase_ = Phase::IDLE;

        emit statusChanged(
            "Failed to send test goal.");

        emit executionStopped();

        return;
    }


    /*
     * IMPORTANT FIX
     *
     * Some navigation/local-planner implementations initialise
     * or refresh planner parameters when a new navigation goal
     * is accepted.
     *
     * Re-apply the test-case motion limits immediately after
     * the goal has been accepted.
     *
     * This makes sure test_case_02 actually uses:
     *
     *     max_vel = 0.6 m/s
     *
     * instead of inheriting the previous test's motion state.
     */
    QThread::msleep(100);

    if (!ros_client_->configureMotion(
            testCase.max_velocity_mps,
            testCase.acceleration_mps2))
    {
        running_ = false;

        waiting_for_load_ = false;

        phase_ = Phase::IDLE;

        emit statusChanged(
            "Failed to re-apply robot motion configuration.");

        emit executionStopped();

        return;
    }


    emit statusChanged(
        QString(
            "Test started: %1 -> %2 "
            "(max velocity: %3 m/s)")
        .arg(start_waypoint_)
        .arg(goal_waypoint_)
        .arg(
            testCase.max_velocity_mps,
            0,
            'f',
            3));
}


// ============================================================
// LOAD ACCEPTED
// ============================================================

void TestExecutionController::loadAccepted()
{
    /*
     * Ignore the callback if the test sequence is
     * not active.
     */
    if (!running_)
    {
        return;
    }

    /*
     * Ignore the callback if the controller is not
     * actually waiting for the load confirmation.
     */
    if (!waiting_for_load_)
    {
        return;
    }


    /*
     * The operator has confirmed that the load is
     * physically placed on the robot.
     */
    waiting_for_load_ = false;


    emit statusChanged(
        "Load confirmed. Starting test.");


    /*
     * load_prompt_shown_ remains TRUE.
     *
     * Therefore:
     *
     * Iteration 1 -> prompt
     * Iteration 2 -> no prompt
     * Iteration 3 -> no prompt
     *
     * for the same test case.
     */
    startCurrentTest();
}


// ============================================================
// TELEMETRY
// ============================================================

void TestExecutionController::telemetryUpdated(
    double velocity,
    double distance,
    double time)
{
    if (!running_)
    {
        return;
    }

    if (current_test_index_ < 0 ||
        current_test_index_ >=
            static_cast<int>(test_cases_.size()))
    {
        return;
    }


    /*
     * If we are waiting for the operator to confirm
     * the load, completely ignore telemetry for the
     * execution state.
     */
    if (waiting_for_load_)
    {
        return;
    }


    const auto& testCase =
        test_cases_[current_test_index_];


    // ========================================================
    // MAXIMUM VELOCITY
    // ========================================================

    max_velocity_achieved_ =
        std::max(
            max_velocity_achieved_,
            velocity);


    // ========================================================
    // ACCELERATION
    // ========================================================

    if (previous_time_ > 0.0 &&
        time > previous_time_)
    {
        const double dt =
            time - previous_time_;

        if (dt > 0.0)
        {
            const double acceleration =
                (velocity -
                 previous_velocity_) /
                dt;

            acceleration_time_data_.append(
                QPointF(
                    time,
                    acceleration));

            emit accelerationDataChanged(
                acceleration_time_data_);
        }
    }

    previous_velocity_ = velocity;

    previous_time_ = time;


    // ========================================================
    // MOVING / BRAKING TELEMETRY
    // ========================================================

    if (phase_ == Phase::MOVING_TO_GOAL ||
        phase_ == Phase::BRAKING)
    {
        velocity_time_data_.append(
            QPointF(
                time,
                velocity));

        velocity_distance_data_.append(
            QPointF(
                distance,
                velocity));

        emit velocityDataChanged(
            velocity_time_data_);

        emit velocityDistanceDataChanged(
            velocity_distance_data_);
    }


    // ========================================================
    // MAXIMUM VELOCITY REACHED
    // ========================================================

    /*
     * IMPORTANT:
     *
     * The controller does NOT start braking at 0.55,
     * 0.50, etc.
     *
     * The configured test-case maximum is the only
     * threshold.
     */
    if (phase_ == Phase::MOVING_TO_GOAL &&
        velocity >= testCase.max_velocity_mps)
    {
        braking_started_ = true;

        braking_start_distance_ =
            distance;

        phase_ = Phase::BRAKING;


        emit statusChanged(
            QString(
                "Maximum velocity reached: %1 m/s")
                .arg(
                    velocity,
                    0,
                    'f',
                    3));


        switch (testCase.braking_type)
        {
            case robot_motion_test_data::BrakingType::STO:
            {
                emit statusChanged(
                    "STO selected. "
                    "Using simulation stop.");

                ros_client_->stopRobot();

                break;
            }


            case robot_motion_test_data::BrakingType::SAFE_STOP:
            {
                emit statusChanged(
                    "Safe-Stop selected. "
                    "Using simulation stop.");

                ros_client_->stopRobot();

                break;
            }


            case robot_motion_test_data::BrakingType::NONE:
            {
                /*
                 * Keep the existing project behavior.
                 */
                emit statusChanged(
                    "No braking selected.");

                ros_client_->stopRobot();

                break;
            }
        }

        return;
    }


    // ========================================================
    // BRAKING COMPLETE
    // ========================================================

    if (phase_ == Phase::BRAKING &&
        std::abs(velocity) < 0.03)
    {
        braking_distance_ =
            std::max(
                0.0,
                distance -
                braking_start_distance_);


        emit statusChanged(
            QString(
                "Braking complete. "
                "Braking distance: %1 m")
                .arg(
                    braking_distance_,
                    0,
                    'f',
                    3));


        /*
         * The iteration is NOT complete.
         *
         * The robot must now return:
         *
         * V72/V74 -> V75
         */
        phase_ =
            Phase::RETURNING_TO_START;


        return_motion_detected_ = false;


        if (!ros_client_->sendGoal(
                "",
                start_waypoint_))
        {
            running_ = false;

            waiting_for_load_ = false;

            phase_ = Phase::IDLE;

            emit statusChanged(
                "Failed to send return-to-start goal.");

            emit executionStopped();

            return;
        }


        emit statusChanged(
            QString(
                "Returning to start: %1")
            .arg(start_waypoint_));

        return;
    }


    // ========================================================
    // RETURNING TO START
    // ========================================================

    if (phase_ == Phase::RETURNING_TO_START)
    {
        /*
         * We only use telemetry here to establish that
         * the robot actually started moving.
         */
        if (std::abs(velocity) > 0.05)
        {
            if (!return_motion_detected_)
            {
                return_motion_detected_ = true;

                emit statusChanged(
                    "Return motion detected.");
            }
        }

        /*
         * The return goal callback is responsible
         * for completing the iteration.
         */
        return;
    }
}


// ============================================================
// GOAL REACHED
// ============================================================

void TestExecutionController::goalReached()
{
    if (!running_)
    {
        return;
    }


    // ========================================================
    // IGNORE CALLBACK WHILE WAITING FOR LOAD
    // ========================================================

    if (waiting_for_load_)
    {
        return;
    }


    // ========================================================
    // TEST GOAL REACHED
    // ========================================================

    if (phase_ == Phase::MOVING_TO_GOAL)
    {
        /*
         * This is the test goal.
         *
         * DO NOT finish the iteration here.
         *
         * The robot still has to complete its movement
         * and then return to the start waypoint.
         */
        emit statusChanged(
            QString(
                "Goal waypoint reached: %1")
                .arg(goal_waypoint_));

        return;
    }


    // ========================================================
    // RETURN GOAL REACHED
    // ========================================================

    if (phase_ == Phase::RETURNING_TO_START)
    {
        /*
         * Protect against a stale goalReached() callback
         * from the previous navigation goal.
         */
        if (!return_motion_detected_)
        {
            emit statusChanged(
                "Ignoring return goal callback. "
                "Return motion has not been detected yet.");

            return;
        }


        /*
         * The robot has completed:
         *
         * V75 -> test goal
         * test goal -> return
         * return -> V75
         */
        phase_ = Phase::IDLE;


        emit statusChanged(
            QString(
                "Return goal reached: %1")
                .arg(start_waypoint_));


        finishCurrentIteration();

        return;
    }
}


// ============================================================
// FINISH CURRENT ITERATION
// ============================================================

void TestExecutionController::finishCurrentIteration()
{
    if (!running_)
    {
        return;
    }

    if (current_test_index_ < 0 ||
        current_test_index_ >=
            static_cast<int>(test_cases_.size()))
    {
        return;
    }


    const auto& testCase =
        test_cases_[current_test_index_];


    emit testFinished(
        QString::fromStdString(
            testCase.name));


    // ========================================================
    // MORE ITERATIONS OF SAME TEST
    // ========================================================

    if (current_iteration_ <
        testCase.iterations)
    {
        ++current_iteration_;


        emit statusChanged(
            QString(
                "Starting iteration %1")
                .arg(
                    current_iteration_));


        /*
         * DO NOT reset load_prompt_shown_.
         *
         * The same physical load remains on the robot.
         */
        startCurrentTest();

        return;
    }


    // ========================================================
    // CURRENT TEST CASE COMPLETE
    // ========================================================

    ++current_test_index_;


    // ========================================================
    // ALL TEST CASES COMPLETE
    // ========================================================

    if (current_test_index_ >=
        static_cast<int>(test_cases_.size()))
    {
        running_ = false;

        waiting_for_load_ = false;

        load_prompt_shown_ = false;

        phase_ = Phase::IDLE;


        emit statusChanged(
            "All tests completed.");

        emit executionCompleted();

        return;
    }


    // ========================================================
    // MOVE TO NEXT TEST CASE
    // ========================================================

    current_iteration_ = 1;


    /*
     * This is a NEW test case.
     *
     * Therefore, if the new test requires a load,
     * the load prompt must appear again.
     */
    load_prompt_shown_ = false;

    waiting_for_load_ = false;

    phase_ = Phase::IDLE;

    return_motion_detected_ = false;


    emit statusChanged(
        QString(
            "Previous test completed. "
            "Preparing next test case."));


    /*
     * The robot is already back at the start waypoint.
     *
     * startCurrentTest() will either:
     *
     * 1. Show the load prompt and wait
     *
     * or
     *
     * 2. Start the next test immediately.
     */
    startCurrentTest();
}


// ============================================================
// CLEAR CURRENT ITERATION DATA
// ============================================================

void TestExecutionController::clearCurrentData()
{
    velocity_time_data_.clear();

    velocity_distance_data_.clear();

    acceleration_time_data_.clear();


    braking_started_ = false;

    return_motion_detected_ = false;


    braking_start_distance_ = 0.0;

    braking_distance_ = 0.0;

    max_velocity_achieved_ = 0.0;


    previous_velocity_ = 0.0;

    previous_time_ = 0.0;


    emit velocityDataChanged(
        velocity_time_data_);

    emit velocityDistanceDataChanged(
        velocity_distance_data_);

    emit accelerationDataChanged(
        acceleration_time_data_);
}


// ============================================================
// STOP
// ============================================================

void TestExecutionController::stop()
{
    if (!running_)
    {
        return;
    }


    ros_client_->stopRobot();


    running_ = false;

    waiting_for_load_ = false;

    load_prompt_shown_ = false;

    phase_ = Phase::IDLE;

    braking_started_ = false;

    return_motion_detected_ = false;


    clearCurrentData();


    emit executionStopped();


    emit statusChanged(
        "Testing stopped. "
        "Current test data discarded.");
}


// ============================================================
// IS RUNNING
// ============================================================

bool TestExecutionController::isRunning() const
{
    return running_;
}